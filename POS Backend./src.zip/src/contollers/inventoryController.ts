/** @format */

import { Request, Response } from "express";
import InventoryModel from "../modal/inventoryModal";

export async function createUpdateProduct(req: Request, res: Response) {
  try {
    // Check if a file is uploaded
    if (!req.file) {
      return res.status(400).json({ message: "No file uploaded" });
    }

    const {
      ItemName,
      ItemCode,
      Brand,
      Category,
      Description,
      Discount,
      UnitPrice,
      IsActive,
    } = req.body;

    // Create a new request object
    const request = {
      ItemName,
      ItemCode,
      Brand,
      Category,
      Description,
      Discount,
      UnitPrice,
      IsActive,
    };

    // Create a new inventory document
    const inventory = new InventoryModel({
      Request: request,
      Image: req.file.buffer,
    });

    // Save the inventory to the database
    await inventory.save();

    res.status(201).json({ message: "Product created successfully" });
  } catch (error) {
    console.error("Failed to create product:", error);
    res.status(500).json({ message: "Something went wrong" });
  }
}
