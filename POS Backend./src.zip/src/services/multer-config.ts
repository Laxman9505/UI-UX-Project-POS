/** @format */

import multer from "multer";

// Configure multer storage
const storage = multer.memoryStorage(); // Store the uploaded file in memory as a buffer

// Create multer instance with the configured storage
const upload = multer({ storage });

export default upload;
