/** @format */

import dotenv from "dotenv";
import express, { NextFunction, Request, Response } from "express";
import mongoose from "mongoose";
import authRouter from "./routes/auth";
import productRouter from "./routes/inventory";
import { CustomError, IErrorResponse } from "./utils/error-handler";

dotenv.config();

// import userRoutes from "./routes/userRoutes";

const app = express();

// Middleware
app.use(express.json());

// Mount the authentication routes
app.use("/auth", authRouter);
app.use("/product", productRouter);

app.use(
  (error: IErrorResponse, req: Request, res: Response, next: NextFunction) => {
    if (error instanceof CustomError) {
      return res.status(error.statusCode).json(error.serializeError());
    }
    next(error);
  }
);

// MongoDB Connection

const mongoURI = process.env.MONGO_URI || ""; // Replace 'mydatabase' with your actual database name
mongoose
  .connect(mongoURI)
  .then(() => {
    console.log("Connected to MongoDB");
  })
  .catch((error) => {
    console.error("MongoDB connection error:", error);
  });

// Routes
// app.use("/users", userRoutes);

export default app;
