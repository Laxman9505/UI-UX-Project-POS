/** @format */

import express, { Router } from "express";
import { createUpdateProduct } from "../contollers/inventoryController";
import upload from "../services/multer-config";

const router: Router = express.Router();

router.post(
  "/createUpdateProduct",
  upload.single("image"),
  createUpdateProduct
);

export default router;
