/** @format */

import { body } from "express-validator";

export const onBoardUserValidator = [
  body("OTP").notEmpty().withMessage("OTP is required"),
  body("FullName").notEmpty().withMessage("Full Name is required"),
  body("Password").notEmpty().withMessage("Password is required"),
  body("Email").notEmpty().withMessage("Email is required"),
  // body("ConfirmPassword")
  //   .notEmpty()
  //   .custom((value, { req }) => {
  //     if (value !== req.body.Password) {
  //       throw new Error("Password confirmation does not match password");
  //     }
  //   }),
  body("PhoneNumber").notEmpty().withMessage("Phone Number is required"),
  body("CountryId").notEmpty().withMessage("Country Id is required"),
  body("CityId").notEmpty().withMessage("City Id is required"),
];
