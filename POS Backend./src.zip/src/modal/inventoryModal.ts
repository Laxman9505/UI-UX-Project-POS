/** @format */

import { Schema, model } from "mongoose";
import { IInventory, IRequest } from "../interfaces/inventoryInterfaces";

const RequestSchema: Schema = new Schema<IRequest>({
  ItemName: {
    type: String,
    required: true,
  },
  ItemCode: {
    type: String,
    required: true,
  },
  Brand: {
    type: String,
  },
  Category: {
    type: String,
    required: true,
  },
  Discount: {
    type: Number,
  },
  UnitPrice: {
    type: Number,
    required: true,
  },
  IsActive: {
    type: Boolean,
    default: true,
  },
});

const InventorySchema: Schema = new Schema<IInventory>({
  Request: {
    type: RequestSchema,
    required: true,
  },
  Image: {
    type: Buffer,
    required: true,
  },
});

const InventoryModel = model<IInventory>("Inventory", InventorySchema);
export default InventoryModel;
